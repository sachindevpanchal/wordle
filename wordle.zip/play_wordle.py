from tkinter import *
from tkinter import Button
import requests


def get_word():
    """ returns a random 5-letter word"""
    url = "https://random-word-api.herokuapp.com/word"
    parameters = {
        "length": 5 
    }
    response = requests.get(url=url, params=parameters)
    l = response.json()[0]
    word = [x for x in l]
    return word


word = get_word()

green = "#00FF00"
yellow = "#FFFF00"
gray = "#808080"

window = Tk()
canvas = Canvas()
window.config(padx=50, pady=50, bg=gray)
window.title("WORDLE")
window.config()

l = []
row_number = 0
turn = 0


def check(answer="", row_list=[]):
    """compare the user answer with the word to guess and assign gray color if letter is not in thw word and yellow if
    it is in the word but not at wright position and green color if letter is in word and is on same position"""
    global row_number, word
    reword = word[:]
    answer = [x for x in answer]
    for i in range(5):
        row_list[row_number][i].config(text=answer[i])
        if answer[i] in word:
            row_list[row_number][i].config(bg=yellow)
            if answer[i] == word[i]:
                row_list[row_number][i].config(bg=green)
                word[i] = 0
        else:
            row_list[row_number][i].config(bg="#FF0000")

    word = reword[:]


def savior(answer="", row_list=[]):
    """takes the user answer entered in entry widget and row_list containing all the label widget then pass it to check
    function """
    global row_number, word
    check(answer=answer, row_list=row_list)
    """ changing global variable row_number to move to next row after entering one guess"""
    row_number += 1


label = Label()


def start():
    global l, row_number, turn, word
    row_number = 0
    """color used in game"""
    green = "#00FF00"
    yellow = "#FFFF00"
    gray = "#808080"
    """creating 30 widgets for the game"""
    row_list = []

    for row in range(6):
        empty = []
        for i in range(5):
            lab = Label(text="□", bd=0, font=("Arial", 50), bg=gray)
            lab.grid(row=row, column=i)
            empty += [lab]
        row_list += [empty]
    """entry widget"""
    entry = Entry(width=33)
    entry.grid(row=6, column=0, columnspan=5)
    entry.focus()
    """button widget to call savior function"""
    button: Button = Button(text="check", command=lambda: [savior(answer=entry.get(), row_list=row_list)],
                            width=33,
                            font=("Arial"))
    button.grid(row=7, column=0, columnspan=7)
    """removing the start and guess button from window"""
    start_button.destroy()

start_button = Button(text="PLAY THE GAME", command=start, width=33, font=("Arial"))
start_button.grid(row=0, column=0, columnspan=6)

window.mainloop()
